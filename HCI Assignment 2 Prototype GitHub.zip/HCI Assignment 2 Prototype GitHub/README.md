# Mock Interview Application

## Setup
1. Clone this repository
2. Run `npm install`
3. Start the development server with `npm start`

## Running in VS Code
Press F5 and select "Launch All" to start both the server and Chrome debugger.

## Features
- Camera/microphone controls
- Interactive chat interface
- Toast notifications
- Sound feedback